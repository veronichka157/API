﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace kursov2
{
    public class Helper
    {
        protected Bitmap original;
        protected string Type;
        protected string SourceFolder;
        protected string DestionationFolder;

    }
}
