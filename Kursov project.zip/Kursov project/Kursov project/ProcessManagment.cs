﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kursov_project
{
    public class ProcessManagment
    {
        public int Type { get; set; }
        public string SourceFolder { get; set; }
        public string DestionationFolder { get; set; }

        public ProcessManagment(int Type, string srcFolder, string dstFolder)
        {
            this.Type = Type;
            this.SourceFolder = srcFolder;
            this.DestionationFolder = dstFolder;
        }

        public void FileReader()
        { }

        public void FileWritter()
        { }

    }
}
