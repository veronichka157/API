﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kursov_project
{
    public class Convert : ProcessManagment
    {
        private int type;
        public string sourceFolder;
        private string destinationFolder;

        public Convert(int Type, string SourceFolder, string DestionationFolder) : base (Type, srcFolder: SourceFolder, dstFolder: DestionationFolder)
        {
            type = Type;
            this.sourceFolder = SourceFolder;
            destinationFolder = DestionationFolder;
        }

        public string Converter(FileInfo foo)
        {
            //Get file extension
            string fileExtension = foo.Extension.ToLower();

            // Get file name without extenstion
            string fileName = foo.Name.Replace(foo.Extension, string.Empty) + ".jpg";

            System.Drawing.Image image = System.Drawing.Image.FromFile
            (base.SourceFolder);

            ImageConverter b = new ImageConverter();

            if (fileExtension == ".png")
            {
                image.Save(base.DestionationFolder, System.Drawing.Imaging.ImageFormat.Jpeg);
            }
            else if (fileExtension == ".jpg")
            {
                image.Save(base.DestionationFolder, System.Drawing.Imaging.ImageFormat.Png);
            }
            else if (fileExtension == ".gif")
            {
                image.Save(base.DestionationFolder, System.Drawing.Imaging.ImageFormat.Gif);
            }

            return (fileExtension);
        }
    }
}

