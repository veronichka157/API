﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Kursov_project
{
    public class Resize : ProcessManagment
    {
        private int type;
        public string sourceFolder;
        private string destinationFolder;

        public Resize(int Type, string SourceFolder, string DestionationFolder) : base (Type, srcFolder: SourceFolder, dstFolder: DestionationFolder)
        {
            this.type = Type;
            this.sourceFolder = SourceFolder;
            this.destinationFolder = DestionationFolder;
        }

        //без запазване на пропорциите(размерите)
        public void Skew()
        {
            Image image = Image.FromFile(base.SourceFolder);
            using (var newImage = ScaleImage(image, 300, 400))
            {
                newImage.Save(base.DestionationFolder, image.RawFormat);
            }
        }

        public static Image ScaleImage(Image image, int maxWidth, int maxHeight)
        {
            var ratioX = (double)maxWidth / image.Width;
            var ratioY = (double)maxHeight / image.Height;
            var ratio = Math.Min(ratioX, ratioY);

            var newWidth = (int)(image.Width * ratio);
            var newHeight = (int)(image.Height * ratio);

            var newImage = new Bitmap(newWidth, newHeight);

            using (var graphics = Graphics.FromImage(newImage))
                graphics.DrawImage(image, 0, 0, newWidth, newHeight);

            return newImage;
        }

        //запазване на пропорциите 
        public void KeepAspect()
        {
            Bitmap original, resizedImage;

            try
            {
                using (FileStream fs = new System.IO.FileStream(base.SourceFolder, System.IO.FileMode.Open))
                {
                    original = new Bitmap(fs);
                }

                int rectHeight = original.Height;
                int rectWidth = original.Width;


                if (original.Height == original.Width)
                {
                    resizedImage = new Bitmap(original, rectHeight, rectHeight);
                }
                else
                {
                    float aspect = original.Width / (float)original.Height;
                    int newWidth, newHeight;


                    newWidth = (int)(rectWidth * aspect);
                    newHeight = (int)(newWidth / aspect);


                    if (newWidth > rectWidth || newHeight > rectHeight)
                    {
                        if (newWidth > newHeight)
                        {
                            newWidth = rectWidth;
                            newHeight = (int)(newWidth / aspect);
                        }
                        else
                        {
                            newHeight = rectHeight;
                            newWidth = (int)(newHeight * aspect);
                        }
                    }
                    resizedImage = new Bitmap(original, newWidth, newHeight);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        //изрязване
        public void Crop()
        {
            Rectangle cropRect = new Rectangle();
            Bitmap src = Image.FromFile(base.SourceFolder) as Bitmap;
            Bitmap target = new Bitmap(cropRect.Width, cropRect.Height);

            using (Graphics g = Graphics.FromImage(target))
            {
                g.DrawImage(src, new Rectangle(0, 0, target.Width, target.Height),
                    cropRect, GraphicsUnit.Pixel);
            }
        }


    }
}